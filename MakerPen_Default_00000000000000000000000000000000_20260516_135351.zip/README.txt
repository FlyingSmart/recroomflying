```
#############################################################
#############################################################
#############################################################
########                                             ########
#######                                               #######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
######                                                 ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ###########################################   ######
######   ###########################################   ######
######     #######################################     ######
######        #################################        ######
######   ##       #########################       ##   ######
######   ######         #############         ######   ######
######   ##########                       ##########   ######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
#######                                               #######
########                                             ########
#############################################################
#############################################################
#############################################################

            +-----------------------------------+
            |  THANK YOU FOR PLAYING REC ROOM!  |
            +-----------------------------------+

From the whole Rec Room team, thank you for playing our game!

                 Be excellent to each other!
```

## File Types

*.binpb           Binary Protocol Buffer data
*.glb             glTF Binary 3D model (importable into Blender, Unity, etc.)

## File Structure

```
{MakerPenExport}/
|
|- README.txt                                  # This file
|- ExportLog_*.log                             # Export process log
|- Warnings.log                                # Export warnings (if any)
|- descriptor_set.binpb                        # Protobuf descriptor set
|
|- MakerPen_*.glb                              # Maker Pen mesh
```

## Reconstructing the runtime drawing-color in Blender

The "ink stick" in the maker pen changes color based on the currently selected drawing color.
In the exported model, that tube is white, but the base color texture's alpha channel indicates what regions
of the base color should be tinted in order to recreate this effect.

If you want to apply your own tint color, the masking is straightforward to reconstruct in Blender's Shader Editor:

  1. Select the Maker Pen body material and open the Shader Editor.
  2. Find the Image Texture node feeding the Principled BSDF's
     Base Color input. Note that it provides both a Color and an
     Alpha output.
  3. Add an RGB node — this will be your custom tint color.
  4. Add a Mix Color node:
       - Set the Blending Mode to Multiply.
       - Connect the Image Texture's Color output to the A input.
       - Connect your RGB color to the B input.
       - Connect the Image Texture's Alpha output to the Factor input.
     This produces "white where alpha = 0, your color where alpha = 1".
  5. Connect the Mix node's Result to the Principled BSDF's
     Base Color input (replacing the direct Image Texture connection).

Now changing your RGB color in step 3 tints the masked region the
same way the in-game shader does.

## descriptor_set.binpb

You can read this file as proto descriptors with 'protoc' or 'buf'.

With protoc (https://protobuf.dev/installation/):

```sh
protoc --decode=google.protobuf.FileDescriptorSet \
  google/protobuf/descriptor.proto \
  < descriptor_set.binpb
```

With buf (https://github.com/bufbuild/buf):

```sh
buf convert \
  --type google.protobuf.FileDescriptorSet \
  --from descriptor_set.binpb \
  --to -#format=txtpb
```

Note that these are only descriptions of the .proto files. They are
not the original .proto files used in game.
