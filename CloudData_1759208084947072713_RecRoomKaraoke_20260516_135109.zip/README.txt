```
#############################################################
#############################################################
#############################################################
########                                             ########
#######                                               #######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
######                                                 ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ############   #############   ############   ######
######   ###########################################   ######
######   ###########################################   ######
######     #######################################     ######
######        #################################        ######
######   ##       #########################       ##   ######
######   ######         #############         ######   ######
######   ##########                       ##########   ######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
######   ###########################################   ######
#######                                               #######
########                                             ########
#############################################################
#############################################################
#############################################################

            +-----------------------------------+
            |  THANK YOU FOR PLAYING REC ROOM!  |
            +-----------------------------------+

From the whole Rec Room team, thank you for playing our game!

                 Be excellent to each other!
```

## File Types

*.binpb           Binary Protocol Buffer data
*.original.binpb  Raw Binary Protocol Buffer data before version migration
*.csv             Comma-separated lookup tables
*.glb             glTF Binary 3D model (importable into Blender, Unity, etc.)
*.json            JSON representation of protobuf data
*.jpg / *.png     Image files
*.wav             Decoded audio

## File Structure

Not all files and folders will be present in every
export. Contents depend on your export settings and
the content of your room.

```
{RoomName}/
|
|- README.txt                                  # This file
|- ExportLog_*.log                             # Export process log
|- Warnings.log                                # Export warnings (if any)
|- descriptor_set.binpb                        # Protobuf descriptor set
|
|- RoomDetails.json                            # Room metadata
|- RoomImage.*                                 # Room thumbnail
|
|- super_room_data.original.binpb              # Raw SuperRoomData
|- super_room_data.binpb                       # Versioned SuperRoomData
|
|- Promo/                                      # Promo images (if any)
| +- Image/
|   +- PromoImage_*.*
|
|- LoadingScreens/                             # Loading screen images (if any)
| +- Image/
|   +- LoadingScreenImage_*.*
|
|- SubRoom_{Id}_{Name}/                        # One folder per subroom
| |- Subroom.json                              # Subroom metadata
| |
| |- persisted_room_data.original.binpb        # Raw subroom data
| |- persisted_room_data.binpb                 # Versioned subroom data
| |
| |- CV2NodeTypes.csv                          # CV2 chip type lookup table
| |- PrefabIds.csv                             # Spawnable tool type lookup table
| |- Scene.glb                                 # 3D shape geometry
| |
| |- Image/                                    # Image assets
| | |- PVImage_*.*                             # From persistence views
| | +- Node_RecNetImage_*.*                    # From CV2 nodes
| |
| |- Holotar/                                  # Holotar recordings (.binpb + .wav)
| | +- PVHolotar_*.*
| |
| |- AudioSampler/                             # Audio sampler recordings (.binpb + .wav)
| | +- *.*
| |
| |- CV2Audio/                                 # CV2 audio recordings (.binpb + .wav)
| | +- Node_SampleAudio_*.*
| |
| |- CV2Holotar/                               # CV2 holotar recordings (.binpb + .wav)
| | +- Node_HolotarRecording_*.*
| |
| +- MeshGen/                                  # Generated meshes
|   +- MeshPresenter_*.glb
|
+- Inventions/                                 # Inventions found in room
  +- Invention_{Id}_{Name}/
    |- Invention.json                          # Invention metadata
    |- InventionDetails.json                   # Invention details
    |- InventionVersion.json                   # Invention version info
    |- InventionImage.*                        # Invention thumbnail
    |
    |- spawnable_template_data.original.binpb  # Raw invention data
    |- spawnable_template_data.binpb           # Versioned invention data
    |
    |- CV2NodeTypes.csv                        # CV2 chip type lookup table
    |- PrefabIds.csv                           # Spawnable tool type lookup table
    |- Scene.glb                               # 3D shape geometry
    |
    |- Image/                                  # Same asset types as subrooms
    |- Holotar/
    |- AudioSampler/
    |- CV2Audio/
    |- CV2Holotar/
    +- MeshGen/
```

### descriptor_set.binpb

You can read this file as proto descriptors with
'protoc' or 'buf'.

With protoc (https://protobuf.dev/installation/):

```sh
protoc --decode=google.protobuf.FileDescriptorSet \
  google/protobuf/descriptor.proto \
  < descriptor_set.binpb
```

With buf (https://github.com/bufbuild/buf):

```sh
buf convert \
  --type google.protobuf.FileDescriptorSet \
  --from descriptor_set.binpb \
  --to -#format=txtpb
```

Note that these are only descriptions of the .proto
files. They are not the original .proto files used
in game.
